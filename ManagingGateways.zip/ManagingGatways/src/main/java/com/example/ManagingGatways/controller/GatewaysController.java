package com.example.ManagingGatways.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ManagingGatways.dto.AssociatedDevicesDto;
import com.example.ManagingGatways.dto.GatewayDto;
import com.example.ManagingGatways.entities.AssociatedDevices;
import com.example.ManagingGatways.entities.Gateways;
import com.example.ManagingGatways.request.AssociatedDevicesDetailsReqModel;
import com.example.ManagingGatways.request.GatewaysDetailsRequestModel;
import com.example.ManagingGatways.request.RequestOperationName;
import com.example.ManagingGatways.response.AssociatedDevicesResponse;
import com.example.ManagingGatways.response.GatewayResponse;
import com.example.ManagingGatways.response.OperationStatusModel;
import com.example.ManagingGatways.response.RequestOperationStatus;
import com.example.ManagingGatways.services.GatewayService;

@RestController
@RequestMapping("gateways") // http://localhost:8080/gatways
public class GatewaysController {

	@Autowired
	GatewayService gatewayService;

// get gateway with associated devices by gateway serial

	@GetMapping(path = "{serial}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public GatewayResponse getGateway(@PathVariable String serial) {
		Gateways returnedGateway = gatewayService.findGatewayBySerial(serial);
		GatewayResponse gatewayResponse = new GatewayResponse();
		BeanUtils.copyProperties(returnedGateway, gatewayResponse);
		gatewayResponse.setAssociatedDevicesList(new ArrayList<>());
		for (AssociatedDevices associatedDevices : returnedGateway.getAssociatedDevicesList()) {
			AssociatedDevicesResponse associatedDevicesResponse = new AssociatedDevicesResponse();
			BeanUtils.copyProperties(associatedDevices, associatedDevicesResponse);
			gatewayResponse.getAssociatedDevicesList().add(associatedDevicesResponse);
		}
		return gatewayResponse;
	}

//	get All gateways with associated  devices
//http://localhost:8080/gateways
	
	@GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<GatewayResponse> getAllGateways() {
		List<Gateways> returnedGatewayList = gatewayService.findAllGateways();
		List<GatewayResponse> gatewayResponseList = new ArrayList<>();
		for (Gateways gateway : returnedGatewayList) {
			GatewayResponse gatewayResponse = new GatewayResponse();
			BeanUtils.copyProperties(gateway, gatewayResponse);
			gatewayResponseList.add(gatewayResponse);
			gatewayResponse.setAssociatedDevicesList(new ArrayList<>());
			for (AssociatedDevices associatedDevices : gateway.getAssociatedDevicesList()) {
				AssociatedDevicesResponse associatedDevicesResponse = new AssociatedDevicesResponse();
				BeanUtils.copyProperties(associatedDevices, associatedDevicesResponse);
				gatewayResponse.getAssociatedDevicesList().add(associatedDevicesResponse);
			}

		}
		return gatewayResponseList;
	}
   
	// create gateway and associated devices
	//http://localhost:8080/gateways
	@PostMapping(consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public GatewayResponse createGatway(@RequestBody GatewaysDetailsRequestModel gatewayDetails) throws Exception {
		if (gatewayDetails.getSerial().isEmpty())
			throw new NullPointerException("the object is null ");
		GatewayDto gatewayDto = new GatewayDto();
		BeanUtils.copyProperties(gatewayDetails, gatewayDto);
		gatewayDto.setAssociatedDevicesList(new ArrayList<>());
		for (AssociatedDevicesDetailsReqModel associatedDevicesDetailsReq : gatewayDetails.getAssociatedDevicesList()) {
			AssociatedDevicesDto associatedDevicesDto = new AssociatedDevicesDto();
			BeanUtils.copyProperties(associatedDevicesDetailsReq, associatedDevicesDto);
			gatewayDto.getAssociatedDevicesList().add(associatedDevicesDto);
		}

		Gateways createdGateways = gatewayService.createGateway(gatewayDto);

		GatewayResponse gatewayResponse = new GatewayResponse();
		BeanUtils.copyProperties(createdGateways, gatewayResponse);
		gatewayResponse.setAssociatedDevicesList(new ArrayList<>());
		for (AssociatedDevices associatedDevices : createdGateways.getAssociatedDevicesList()) {
			AssociatedDevicesResponse associatedDevicesResponse = new AssociatedDevicesResponse();
			BeanUtils.copyProperties(associatedDevices, associatedDevicesResponse);
			gatewayResponse.getAssociatedDevicesList().add(associatedDevicesResponse);
		}
		return gatewayResponse;
	}


	//@PutMapping(path = "{serial}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {MediaType.APPLICATION_JSON_VALUE })
	
	// add associated device for specific gateway

	@PostMapping(path = "{serial}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public AssociatedDevicesResponse addDeviceForGateWay(@PathVariable String serial,
			@RequestBody AssociatedDevicesDetailsReqModel associatedDevicesDetailsReq) throws Exception {
		AssociatedDevicesDto associatedDevicesDto = new AssociatedDevicesDto();
		BeanUtils.copyProperties(associatedDevicesDetailsReq, associatedDevicesDto);
		AssociatedDevicesDto returnedAssociatedDevicesDto = gatewayService.updateGateway(serial, associatedDevicesDto);
		AssociatedDevicesResponse associatedDevicesResponse = new AssociatedDevicesResponse();
		BeanUtils.copyProperties(returnedAssociatedDevicesDto, associatedDevicesResponse);
		return associatedDevicesResponse;
	}

	// delete gateway with associated devices

	@DeleteMapping(path = "{serial}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public OperationStatusModel deleteGateWay(@PathVariable String serial) throws Exception {
		OperationStatusModel retrnedValue = new OperationStatusModel();
		retrnedValue.setOperationName(RequestOperationName.DELETE.name());
		gatewayService.deleteGateways(serial);
		retrnedValue.setOperationResult(RequestOperationStatus.SUCCESS.name());
		return retrnedValue;
	}

	// delete associated devices with deviceId
	//http://localhost:8080/gateways/device/

	@DeleteMapping(path = "/device/{deviceId}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public OperationStatusModel deleteAssociatedDevice(@PathVariable Long deviceId) throws Exception {
		OperationStatusModel retrnedValue = new OperationStatusModel();
		retrnedValue.setOperationName(RequestOperationName.DELETE.name());
		gatewayService.deleteAssociatedDevice(deviceId);
		retrnedValue.setOperationResult(RequestOperationStatus.SUCCESS.name());
		return retrnedValue;
	}

}
