package com.example.ManagingGatways.services.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ManagingGatways.dto.AssociatedDevicesDto;
import com.example.ManagingGatways.dto.GatewayDto;
import com.example.ManagingGatways.entities.AssociatedDevices;
import com.example.ManagingGatways.entities.Gateways;
import com.example.ManagingGatways.repositries.AssociatedDevicesRepository;
import com.example.ManagingGatways.repositries.GatewaysRepository;
import com.example.ManagingGatways.services.GatewayService;

@Service
public class GatewayServiceImp implements GatewayService {

	@Autowired
	GatewaysRepository gatewaysRepository;
	@Autowired
	AssociatedDevicesRepository associatedDevicesRepository;

	@Override
	public Gateways createGateway(GatewayDto gatewayDto) throws Exception {
		Gateways newGateways = new Gateways();
		BeanUtils.copyProperties(gatewayDto, newGateways);
		if(gatewaysRepository.findBySerial(newGateways.getSerial())!=null)
		throw new Exception("the serial must be unique no duplication");
		boolean ipFormat = newGateways.getiPaddress().matches("^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.(?!$)|$)){4}$");
		if(!ipFormat) {
			throw new Exception(" its wrong format it should be like 198.2.1.1");
		}
		if(gatewayDto.getAssociatedDevicesList().size() > 10)
			throw new Exception(" can not add associated devices more than 10");

		Gateways savedGateways = gatewaysRepository.save(newGateways);
		savedGateways.setAssociatedDevicesList(new ArrayList<>());
		for (AssociatedDevicesDto associatedDevicesDto : gatewayDto.getAssociatedDevicesList()) {
			AssociatedDevices associatedDevices = new AssociatedDevices();
			BeanUtils.copyProperties(associatedDevicesDto, associatedDevices);
			associatedDevices.setGateway(savedGateways);
			associatedDevicesRepository.save(associatedDevices);
			savedGateways.getAssociatedDevicesList().add(associatedDevices);
		}
		return savedGateways;
	}

	@Override
	public Gateways findGatewayBySerial(String serial) {
		Gateways gateways = gatewaysRepository.findBySerial(serial);
		return gateways;
	}

	@Override
	public List<Gateways> findAllGateways() {
		List<Gateways> gatewaysList = gatewaysRepository.findAll();
		return gatewaysList;
	}

	@Override
	public AssociatedDevicesDto updateGateway(String serial, AssociatedDevicesDto associatedDevicesDto)
			throws Exception {
		Gateways gateways = gatewaysRepository.findBySerial(serial);
		int devicesCount = (int) associatedDevicesRepository.countByGateway(gateways);
		if (devicesCount > 10)
			throw new Exception("can not add associated devices more than 10");
		
		AssociatedDevices associatedDevices = new AssociatedDevices();
		BeanUtils.copyProperties(associatedDevicesDto, associatedDevices);
		associatedDevices.setGateway(gateways);
		associatedDevicesRepository.save(associatedDevices);
		AssociatedDevicesDto returnedAssociatedDevicesDto = new AssociatedDevicesDto();
		BeanUtils.copyProperties(associatedDevices, returnedAssociatedDevicesDto);
		return returnedAssociatedDevicesDto;
	}

	@Override
	public void deleteGateways(String serial) throws Exception {
		Gateways gateways = gatewaysRepository.findBySerial(serial);
		if (gateways == null)
			throw new Exception("gateWay not found with serial " + gateways);
		gatewaysRepository.delete(gateways);
	}

	@Override
	public void deleteAssociatedDevice(Long deviceId) throws Exception {
		AssociatedDevices associatedDevices = associatedDevicesRepository.findById(deviceId).get();
		if (associatedDevices == null)
			throw new Exception("device not found with Id " + deviceId);
		associatedDevicesRepository.delete(associatedDevices);
	}

}
