package com.example.ManagingGatways;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagingGatwaysApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagingGatwaysApplication.class, args);
	}

}
