package com.example.ManagingGatways.response;

public enum RequestOperationStatus {
	SUCCESS, ERROR
}
