package com.example.ManagingGatways.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Pattern;


@Entity(name = "gateways")
public class Gateways implements Serializable {

	private static final long serialVersionUID = 2400400553636192691L;
    private static final String IPV4_ADDRESS_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.(?!$)|$)){4}$";

	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable = false ,unique = true)
	private String serial;
	
	@Column(nullable = false )
	private String name;
	
	
    @Pattern(regexp = IPV4_ADDRESS_PATTERN, message = "IP Address should have IPv4 format e.g. '192.168.1.1'")
	@Column(columnDefinition = "varchar(50) default '192.168.1.1'" )
	private String iPaddress;
	
   
   @OneToMany(cascade =CascadeType.ALL, fetch = FetchType.EAGER ,mappedBy = "gateway")
   private List<AssociatedDevices> associatedDevicesList;

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getiPaddress() {
		return iPaddress;
	}

	public void setiPaddress(String iPaddress) {
		this.iPaddress = iPaddress;
	}

	public List<AssociatedDevices> getAssociatedDevicesList() {
		return associatedDevicesList;
	}

	public void setAssociatedDevicesList(List<AssociatedDevices> associatedDevicesList) {
		this.associatedDevicesList = associatedDevicesList;
	}
	
	
	
	
}
