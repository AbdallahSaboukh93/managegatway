package com.example.ManagingGatways.request;

import java.util.List;




public class GatewaysDetailsRequestModel {

	private String serial;

	private String iPaddress;
	
	private String name;

	

	private List<AssociatedDevicesDetailsReqModel> associatedDevicesList;

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public List<AssociatedDevicesDetailsReqModel> getAssociatedDevicesList() {
		return associatedDevicesList;
	}

	public void setAssociatedDevicesList(List<AssociatedDevicesDetailsReqModel> associatedDevicesList) {
		this.associatedDevicesList = associatedDevicesList;
	}

	public String getiPaddress() {
		return iPaddress;
	}

	public void setiPaddress(String iPaddress) {
		this.iPaddress = iPaddress;
	}


}
