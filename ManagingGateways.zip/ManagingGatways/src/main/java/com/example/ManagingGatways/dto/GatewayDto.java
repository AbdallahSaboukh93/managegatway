package com.example.ManagingGatways.dto;

import java.io.Serializable;
import java.util.List;

import com.example.ManagingGatways.entities.AssociatedDevices;

public class GatewayDto implements Serializable  {
	private static final long serialVersionUID = 1L;
	private Long id;
	
	private String serial;

	private String name;

	private String iPaddress;

	private List<AssociatedDevicesDto> associatedDevicesList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public String getiPaddress() {
		return iPaddress;
	}

	public void setiPaddress(String iPaddress) {
		this.iPaddress = iPaddress;
	}

	public List<AssociatedDevicesDto> getAssociatedDevicesList() {
		return associatedDevicesList;
	}

	public void setAssociatedDevicesList(List<AssociatedDevicesDto> associatedDevicesList) {
		this.associatedDevicesList = associatedDevicesList;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
