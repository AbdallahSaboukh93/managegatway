package com.example.ManagingGatways.request;

public enum RequestOperationName {
	DELETE
}
