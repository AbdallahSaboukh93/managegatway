package com.example.ManagingGatways.repositries;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.ManagingGatways.entities.Gateways;

public interface GatewaysRepository extends CrudRepository<Gateways, Long> {

	Gateways findBySerial(String serial);
	
	List<Gateways> findAll();
	
}
