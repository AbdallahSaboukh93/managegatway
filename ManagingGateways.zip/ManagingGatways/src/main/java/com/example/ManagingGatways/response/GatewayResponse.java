package com.example.ManagingGatways.response;

import java.io.Serializable;
import java.util.List;

import com.example.ManagingGatways.entities.AssociatedDevices;

public class GatewayResponse implements Serializable  {
	
	private String serial;

	private String name;

	private String iPaddress;

	private List<AssociatedDevicesResponse> associatedDevicesList;

	
	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public String getiPaddress() {
		return iPaddress;
	}

	public void setiPaddress(String iPaddress) {
		this.iPaddress = iPaddress;
	}

	public List<AssociatedDevicesResponse> getAssociatedDevicesList() {
		return associatedDevicesList;
	}

	public void setAssociatedDevicesList(List<AssociatedDevicesResponse> associatedDevicesList) {
		this.associatedDevicesList = associatedDevicesList;
	}

	
}
