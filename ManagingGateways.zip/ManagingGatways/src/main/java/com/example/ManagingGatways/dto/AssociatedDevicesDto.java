package com.example.ManagingGatways.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.example.ManagingGatways.entities.Gateways;

public class AssociatedDevicesDto {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String vender;
	
	private Date createdDate;
	
	private String status;
	
	private Gateways  gateways ;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVender() {
		return vender;
	}

	public void setVender(String vender) {
		this.vender = vender;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public Gateways getGateways() {
		return gateways;
	}

	public void setGateways(Gateways gateways) {
		this.gateways = gateways;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
