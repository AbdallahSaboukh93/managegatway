package com.example.ManagingGatways.repositries;


import org.springframework.data.repository.CrudRepository;

import com.example.ManagingGatways.entities.AssociatedDevices;
import com.example.ManagingGatways.entities.Gateways;

public interface AssociatedDevicesRepository extends CrudRepository<AssociatedDevices, Long> {
	long countByGateway(Gateways gateway);
}
