package com.example.ManagingGatways.services;

import java.util.List;

import com.example.ManagingGatways.dto.AssociatedDevicesDto;
import com.example.ManagingGatways.dto.GatewayDto;
import com.example.ManagingGatways.entities.Gateways;

public interface GatewayService {
	Gateways createGateway(GatewayDto gatewayDto) throws Exception ;;

	Gateways findGatewayBySerial(String serial);

	public AssociatedDevicesDto updateGateway(String serial, AssociatedDevicesDto associatedDevicesDto)throws Exception;

	public void deleteGateways(String serial)throws Exception ;

	public void deleteAssociatedDevice(Long deviceId) throws Exception ;
	
	public List<Gateways> findAllGateways() ;

}
