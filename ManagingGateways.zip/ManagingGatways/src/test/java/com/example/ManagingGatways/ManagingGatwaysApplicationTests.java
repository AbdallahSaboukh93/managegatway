package com.example.ManagingGatways;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagingGatwaysApplicationTests {

	@Test
	void contextLoads() {
	}

}
